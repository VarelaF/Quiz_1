#include <iostream>
#include <string.h>
#include <string>
#include <conio.h>
#include<windows.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

	using namespace std;
	string Articulos[]={"Detergente","Alcohol","Jabon","Esponjas"};
	string codigo[]={"001","002","003","004"};
	int StockArticulos[]={13,20,7,25};
	int PrecioArticulo[]={3550,2800,4380,325};
	string Venta[10]={""};
	int Cantidad_Vendida[]={};
	
	void gotoxy(int x ,int y)
	{
		COORD coord;
		coord.X=x;
		coord.Y=y;
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);	
	}

	void MostrarArticulos(){/* codigo articulo  cant  precio*/
		system("cls");		
		cout<<"CODIGO\t   ARTICULOS\t   EXISTENCIA\t  PRECIO\n";
		for(int i=0;i<4;i++){
			cout<<"\n";
			cout<<codigo[i];
			cout<<"        ";
			cout<<Articulos[i];
			cout<<"\t\t";
			cout<<StockArticulos[i];
			cout<<"\t  ";
			cout<<PrecioArticulo[i];
		}
	printf("\n==============================================================");		
		for(int i=0;i<4;i++){
			cout<<"\n";	
		}							
	}

	void RealizarVenta(){/* xxxxxxxxxxxxxxx  Registra la venta  xxxxxxxxxxxxxxx*/
		MostrarArticulos();
		string codigoIngresado;	
		int CantidadVendida=0;
		int PosicVector=0;
		char eleccion;
		int totalVendido=0;
		
		do{
			gotoxy(0,8);cout<<"Digite el codigo a vender: ";
			cin>>codigoIngresado;	
			printf("\nCantidad a vender: ");
			cin>>CantidadVendida;
			cout<<"================================ \n";
	
			for(int i=0;i<4;i++){			
		
				if(codigo[i]==codigoIngresado){
				
					for(int j=0;j<1;j++){
						Venta[PosicVector] = codigo[i];	
						Cantidad_Vendida[PosicVector] = CantidadVendida;					
					}
					PosicVector++;							
				}							
			}					
			cout<<"\n �desea ingresar otra venta? (s/n): ";	
			cin>>eleccion;
			if (eleccion=='n'){	break;}			
		}while(codigoIngresado!="s");		
		cout<<"\nRegistro de la venta: \n";
		cout<<"--------------------------------------------------------------- ";	
			cout<<"\nCODIGO\t   ARTICULOS\t   CANTIDAD\t  PRECIO UNIT\t  SUBTOTAL\n";
		for(int i=0;i<3;i++){			
			for(int j=0;j<4;j++){	
				if(Venta[i]==codigo[j]){
					cout<<Venta[i]<<"\t   ";
					cout<<Articulos[j];
					cout<<"\t    "<<Cantidad_Vendida[i];
					cout<<"\t\t   "<<PrecioArticulo[j];
					totalVendido=PrecioArticulo[j]*Cantidad_Vendida[i];
					cout<<"\t\t    "<<totalVendido<<endl;
				}
			}			
		}
		getch();				
	}

	void Menu(){
		int op;
		do{
			setlocale(LC_ALL, "");
			system("cls");
			printf("\n==========================================");
			printf("\nSISTEMA DE VENTAS\n");
			printf("==========================================\n\n\n\n");			
			printf("-Opcion 1: Realizar venta\n");
			printf("-Opcion 2: Mostrar Art�culos\n");
			printf("-Opcion 3: Salir\n");
			printf("\nDigite una opcion: ");
			scanf("%i",&op);
			
			switch (op)
			{
				case 1:
					RealizarVenta();
				break;
				case 2:
					MostrarArticulos();
					getch();
				break;
				case 3:					
				break;
			}
		
		}while(op!=3);						
	}

int main(int argc, char** argv) {	
	Menu();	
	return 0;
}
